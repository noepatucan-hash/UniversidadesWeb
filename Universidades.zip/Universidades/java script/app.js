function reloj(){
let fecha = new Date();
document.getElementById("reloj").innerHTML = fecha.toLocaleTimeString();
}

setInterval(reloj,1000);


document.getElementById("registro").addEventListener("submit",function(e){

let nombre = document.querySelector("input[name='nombre']").value;

if(nombre.length < 3){
alert("El nombre debe tener al menos 3 letras");
e.preventDefault();
}

});